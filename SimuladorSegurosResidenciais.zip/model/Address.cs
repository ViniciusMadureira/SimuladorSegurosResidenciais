namespace Classes
{
	public class Endereço
	{
		private string logradouro;

		private int numero;

		private int CEP;

		private void atribuirLogradouro(string logradouro)
		{

		}

		public string obterLogradouro()
		{
			return null;
		}

		private void atribuirNumero(int numero)
		{

		}

		public int obterNumero()
		{
			return 0;
		}

		private void atribuirCEP(int CEP)
		{

		}

		public int obterCEP()
		{
			return 0;
		}

	}

}

