namespace Classes
{
	public class ContratoDeSeguro
	{
		private double valorMensal;

		private double valorFranquia;

		private bool coberturaRoubo;

		private bool coberturaDesastre;

		private void calcularValorMensal(bool coberturaRoubo, bool coberturaDesastre)
		{

		}

		private void calcularValorFranquia()
		{

		}

	}

}

