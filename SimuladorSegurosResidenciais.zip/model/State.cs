namespace Classes
{
	public class Estado
	{
		private string nome;

		private char[] sigla;

		public Estado obterEstado()
		{
			return null;
		}

	}

}

