namespace Classes
{
	public class Cidade
	{
		private string nome;

		private double indiceIndividual;

		public double obterIndiceIndividual()
		{
			return 0;
		}

		public Cidade obterCidade()
		{
			return null;
		}

	}

}

