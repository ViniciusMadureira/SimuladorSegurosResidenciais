namespace Classes
{
	public class Cidade
	{
		private string name;
		private double individualIndex;		
		public double getIndividualIndex()
		{
			return 0;
		}

		public Cidade getCity()
		{
			return null;
		}



	}

}

